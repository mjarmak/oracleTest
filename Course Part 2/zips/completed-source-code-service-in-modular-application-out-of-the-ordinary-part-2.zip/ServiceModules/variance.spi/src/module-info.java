module variance.spi {
    exports variance.spi;
}