module gamble.slots.games {
    requires gamble.slots.spi;
    uses gamble.slots.spi.PayOffService;
}