module test.spi {
    exports test.spi;
}