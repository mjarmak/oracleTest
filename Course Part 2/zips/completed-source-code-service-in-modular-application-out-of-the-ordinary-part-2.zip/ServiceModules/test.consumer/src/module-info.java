module test.consumer {
    requires test.spi;
    uses test.spi.TestService;
}