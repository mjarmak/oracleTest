module sample.core {
    exports sample.core;
}