/*
The Learn Programming Academy
Java SE 11 Developer 1Z0-819 OCP Course - Part 2
Section 17 -Annotations
Topic:  Deprecating Package & Module
*/

package abc;

import test.TestClass;

public class TestingClass {
    public static void main(String[] args) {
        TestClass tc = new TestClass();
        tc.doSomething();
    }
}