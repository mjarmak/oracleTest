import annotations.ModuleAnnotation;

@Deprecated
@ModuleAnnotation
module TestModuleAnnotations {
    exports test;
}