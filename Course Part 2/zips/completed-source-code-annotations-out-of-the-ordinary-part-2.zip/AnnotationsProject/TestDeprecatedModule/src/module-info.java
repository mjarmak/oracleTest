module TestDeprecatedModule {
    requires TestModuleAnnotations;
}