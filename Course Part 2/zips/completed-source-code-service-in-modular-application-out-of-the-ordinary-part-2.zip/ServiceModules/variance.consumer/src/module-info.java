module variance.consumer {
    requires variance.spi;
    uses variance.spi.MyService1;
    uses variance.spi.MyService2;
}