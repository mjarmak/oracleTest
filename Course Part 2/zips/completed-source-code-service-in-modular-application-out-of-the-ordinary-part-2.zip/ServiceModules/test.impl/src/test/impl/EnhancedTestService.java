/*
The Learn Programming Academy
Java SE 11 Developer 1Z0-819 OCP Course - Part 2
Section 10: Services in Modular Application
Topic:  Extended the service interface
*/

package test.impl;

public interface EnhancedTestService extends test.spi.TestService {

}