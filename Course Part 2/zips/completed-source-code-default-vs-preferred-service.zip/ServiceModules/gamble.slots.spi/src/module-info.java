module gamble.slots.spi {
    exports gamble.slots.spi;
}