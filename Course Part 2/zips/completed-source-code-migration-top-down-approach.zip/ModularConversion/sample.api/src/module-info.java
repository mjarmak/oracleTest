module sample.api {
    requires sample.core;
    requires sample.entity;
    requires sample.service;
    requires java.logging;
}