/*
The Learn Programming Academy
Java SE 11 Developer 1Z0-819 OCP Course - Part 2
Section 17 -Annotations
Topic:  Package & Module Annotations
*/

package test;

public class TestClass {
    public static void main(String[] args) {
        new TestClass().doSomething();
    }

    public void doSomething() {
        System.out.println("Do Something");
    }
}